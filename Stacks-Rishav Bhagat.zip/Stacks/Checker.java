public interface Checker {
    public boolean check(Book book);
}