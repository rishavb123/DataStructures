package io.bhagat.paint.items;

import java.awt.Graphics2D;

public abstract class DrawableItem {
    
    public abstract void draw(Graphics2D g);

    public void update(long dt) {}

}