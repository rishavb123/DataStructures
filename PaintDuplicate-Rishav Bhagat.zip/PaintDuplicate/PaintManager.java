public class PaintManager {

    
    public PaintManager() {

    }

}