public class PaintProgram {

    private PaintManager pm;

    public static void main(String[] args) {
        new PaintProgram();
    }
}